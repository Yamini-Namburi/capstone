## Udacity Capstone Project for Cloud DevOps Nanodegree.
 Please follow the screenshots to deploy the application
